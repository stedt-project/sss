These MIF files were generated from the final HPTB book files (CD archive "HPTB FINAL 20030606 JAM"), using the exact same fonts used to produce the final PDF sent to UC Press.
